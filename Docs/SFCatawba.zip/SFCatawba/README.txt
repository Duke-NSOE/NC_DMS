These CSV files are the results from uplift calculations for the South Fork Catawba (SFC)

Each file represents a different scenario:
 BF - Buffere forestation
 DD - Downstream distance to nearest dam
 DF - Decrease max flow
 NR - Nutrient reduction 
 SA - Stream alteration (lower velocity 10%)
 SC - Stream cooling
 UD - Upstream distance to nearest dam
 UE - Urban expansion (avoided conversion)
 WE - Wetland expansion
 
Within each file the columns include
 GRIDCODE - NHD Gridcode/FeatureID
 REACHCODE - NHD REACHCODE
 MeanLikelihood - Mean Habitat Likelihood, averaged across all focal species
 MeanUplift - Mean change in habitat likelihood from the scenario alterations
 UpliftRank - Mean Uplift in deciles
 <Species>_cur - Maxent predicted habitat likelihood under current conditions for the species
 <Species>_up - Estimated uplift for the species 
 
 ****  THESE VALUES REPRESENT A DRAFT - NOT FOR CIRCULATION *****
 John.Fay@duke.edu
 Sept 28 2015